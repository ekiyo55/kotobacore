KotobaCore optional dictionaries
================================

この zip 内の辞書は KotobaCore のローダーから参照されません
(loader は resources/dict/ 直下の固定7ファイル名のみ読み込み)。
利用方法が決まるまでの保留データです。展開・投入は明示的な指示があるまで行わないこと。

1. jpx_listed_companies.csv
   - 日本の全上場企業 (内国株式: プライム/スタンダード/グロース) 3459 社
   - 出典: JPX 東証上場銘柄一覧 data_j.xls (データ日付 20260731)
   - entity.csv 互換6列 + メタ列 (code=証券コード, market=市場区分, sector=33業種)
   - 銘柄名は NFKC 正規化済み。entity.csv 登録済みの 254 社は除外済み
   - 注意: 一般名詞と同形の社名が含まれる。投入時は要精査

2. wikipedia_japan_unclassified.csv
   - Wikipedia「日本」記事リンク由来の固有名詞候補のうち未分類 634 件 (2026-08-18 抽出)
   - 列: surface, subcategory, keep_as_unit, qualifier
   - entity.csv 形式ではない。投入時は type 判定と精査が必要
